// This file is part of www.nand2tetris.org
// and the book "The Elements of Computing Systems"
// by Nisan and Schocken, MIT Press.
// File name: projects/04/Fill.asm

// Runs an infinite loop that listens to the keyboard input. 
// When a key is pressed (any key), the program blackens the screen,
// i.e. writes "black" in every pixel. When no key is pressed, the
// program clears the screen, i.e. writes "white" in every pixel.


@posizione
M=0 // inizia in alto a sinistra

(LOOP)
@KBD
D=M

@BIANCO
D;JEQ // se non è premuto un tasto salta al bianco

@NERO
0;JMP // altrimenti salta al nero

(BIANCO)
@posizione
D=M

@LOOP
D;JLT // salta se abbiamo finito

@posizione
D=M
@SCREEN
A=A+D // calcola la posizione sullo schermo
M=0 // riempi con bianco
@posizione
M=M-1 // decrementa la posizione
@LOOP
0;JMP // salta al loop

(NERO)
@posizione
D=M
@8192 // massimo
D=D-A

@LOOP
D;JGE // salta se abbiamo terminato

@posizione
D=M

@SCREEN
A=A+D // calcola la posizione sullo schermo
M=-1 // riempi col nero

@posizione
M=M+1 // incrementa la posizione
@LOOP
0;JMP // salta al loop

(END)
@END
0;JMP